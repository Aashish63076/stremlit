import cv2
import os
import streamlit as st
st.title(" Face recognizor ")
if st.button("Create dataset"):
    folder="C:/Users/akpan/Desktop/Artificial_intelligence/Day_7/dataset"
    sub_folder=input("Enter user name")
    path=os.path.join(folder,sub_folder)
    if not os.path.isdir(path):
        os.mkdir(path)
        
    (height,width)=(200,150)
    algo="haarcascade_frontalface_default.xml"
    face_cascade=cv2.CascadeClassifier(algo)
    count=1
    cam = cv2.VideoCapture(0)
    while True:
        text="Person Not Detected"
        colour=(0,0,255)
        print(count)
        _,img=cam.read()
        grayimg=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)    
        face=face_cascade.detectMultiScale(grayimg,1.3,4)
        for (x,y,w,h) in face:
            cv2.rectangle(img,(x,y),(x+w,y+h),(0,255,0),2)
            text="Person Detected"
            colour=(0,255,0)
            face=grayimg[y:y+h,x:x+w]
            face_resize=cv2.resize(face,(width,height))
            cv2.imwrite('%s/%s.png'%(path,count),face_resize)
        
        cv2.putText(img,text,(50,20),cv2.FONT_HERSHEY_SIMPLEX,0.5,colour,2)
        cv2.imshow("face img",img)    
        cv2.waitKey(1) 
        count+=1
        if count>100:
            break
    print( "face dataset successfully saved at file location : " +path)
    cam.release()
    cv2.destroyAllWindows()





