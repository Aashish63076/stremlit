import streamlit as st
import joblib
import pandas as pd
page=st.sidebar.radio("Navgation bar",["Diabetes Predictor",'About Us'])
if page=="Diabetes Predictor":
    st.markdown(" # Diabetes Predictor :hospital:")
    try:
        name,age,bloodpressure=st.columns(3)
        name=name.text_input("Name")
        age=age.text_input("Age (In year)")
        blood=bloodpressure.text_input("Blood Pressure")
        glucose,insulin,skinthickness=st.columns(3)
        glucose=glucose.text_input("Glucose")
        insulin=insulin.text_input("Insulin")
        skinThickness=skinthickness.text_input("Skin Thickness")
        pregnancies,DiabetesPedigreeFunction,BMI=st.columns(3)
        pregnancies=pregnancies.text_input("Pregnancies")
        pedigreen_function=DiabetesPedigreeFunction.text_input("Diabetes Pedigree Function")
        bmi=BMI.text_input("BMI")
        a,b,c=st.columns(3)
    except:
        st.write(" Dear User Please Fill All right value")
    if b.button(" Check your Diabetes status"):
        data=[[pregnancies,glucose,blood,skinThickness,insulin,bmi,pedigreen_function,age]]
        loaded_model=joblib.load('diabetes_prediction_model.pkl')
        output=loaded_model.predict(data)
        if output[0]==1:
            s="Dear "+name+" you are a diabetes Patient"
            st.error(s)
        else:
            s="Dear "+name+" you are Not diabetes Patient"
            st.success(s)
if page=='About Us':
    st.title(" This is a page about dataset")

    st.text( "This is a dataset which is used in the predictor .")
    st.text("Source of this dataset is Kaggle")
    data=pd.read_csv("C:\\Users\\akpan\\Desktop\\streamlit_project\\Dataset\\diabetes.csv")
    d=pd.DataFrame(data)
    st.dataframe(d)
    st.area_chart(d[["Outcome","Age"]])


