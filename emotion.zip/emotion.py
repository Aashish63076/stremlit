"""import streamlit as st
from facial_emotion_recognition import EmotionRecognition as er
import cv2
st.title("Emotion Recognizer")
st.write( "This is a web app for Emotion Recognition")


if st.button("Check your Emotion"):
    #er=EmotionRecognition(device='cpu')
    cam=cv2.VideoCapture(0)
    while True :
        _,frame=cam.read()
        frame = er.recognise_emotion(frame,return_type='BGR')
        st.image(cv2.imshow('frame',frame))
        if cv2.waitKey(1)== ord('q'):
            break
    cam.relase()
    cv2.destroyAllWindows()
"""
import streamlit as st
import cv2 as cv2
from facial_emotion_recognition import EmotionRecognition 

st.title('Streamlit OpenCV Camera Test')

MAX_FRAMES = st.slider("Select number of frames to render:", min_value=60, max_value=600, value=300, step=30)
run = st.button("Click to render server camera")

if run:
    capture = cv2.VideoCapture(0)
    img_display = st.empty()
    for i in range(MAX_FRAMES):
        ret, img = capture.read()
        frame = EmotionRecognition.recognise_emotion(img,return_type='BGR')
        img_display.image(frame, channels='BGR')
    capture.release()
    st.markdown("Render complete")